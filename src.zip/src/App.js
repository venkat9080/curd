
import './App.css';
import Sample from './components/Sample';
import 'bootstrap/dist/css/bootstrap.min.css';


function App() {
  return (
    <div className="App">
      
        
        <Sample/>
      
    </div>
  );
}

export default App;
